
public class OrderedState implements PhotographySchedulingState{

	@Override
	public void nextOrder(PhotographySchedulingContext pkg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void prevOrder(PhotographySchedulingContext pkg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void currentOrderStatus() {
		// TODO Auto-generated method stub
		System.out.print("Order confirmed! Not completed yet.");
	}
	
}
